package com.example.aplicaciondaniel

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class bienvenida : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bienvenida)

        val nombreImagen = intent.getStringExtra("NAME_EXTRA")
        val textView3: TextView = findViewById(R.id.textView3)

        // Muestra el nombre en el TextView
        textView3.text = nombreImagen

        val btnVolver: Button = findViewById(R.id.btnVolver)

        btnVolver.setOnClickListener {
            // Crea el Intent para redirigir a SecondActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }



    }
}