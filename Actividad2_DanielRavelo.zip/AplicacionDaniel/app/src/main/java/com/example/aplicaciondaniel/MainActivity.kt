package com.example.aplicaciondaniel

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnIngresar: Button = findViewById(R.id.btnIngresar)
        val nombreImagen: EditText = findViewById(R.id.nombreImagen)

        btnIngresar.setOnClickListener {
            // Obtiene el texto del EditText
            val nombreImagen = nombreImagen.text.toString()

            // Crea el Intent y agrega el nombre como extra
            if (nombreImagen == "") {
                Toast.makeText(this, "Ingresa el nombre", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, bienvenida::class.java).apply {
                    putExtra("NAME_EXTRA", nombreImagen)
                }
                startActivity(intent) // Inicia la nueva Activity
            }

        }




    }
}